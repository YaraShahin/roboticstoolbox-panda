# Path Planning

# DXform

- Distance transform navigation class which implements the distance transform navigation algorithm which computes minimum distance paths
    
    ```python
    from roboticstoolbox import Bicycle, RandomPath, VehicleIcon, DXform
    from math import atan2, sqrt, pi
    from scipy.io import loadmat
    import matplotlib.pyplot as plt
    
    def go_target(X, Y):
        diff_x = 1
        diff_y = 1
        while abs(diff_x) > 0.1 and abs(diff_y) > 0.1:
            diff_x = X - car.x[0]
            diff_y = Y - car.x[1]
    
            dist = sqrt(pow(diff_x, 2)+pow(diff_y, 2))
            ang = atan2(diff_y, diff_x)
    
            car.step(1, ang-car.x[2])
            car._animation.update(car.x)
            plt.pause(0.005)
        return
    
    if __name__ == "__main__":
        #100, 50, 30, 20, 90
        dim = int(input("Enter square grid size: "))
        init_x = int(input("Enter car starting x: "))
        init_y = int(input("Enter car starting y: "))
    
        goal_x = int(input("Enter target x: "))
        goal_y = int(input("Enter target y: "))
    
        goal = [goal_x, goal_y]
    
        #define the robot icon object for the animation
        anim = VehicleIcon('/home/yara/CovCE/Lab08/redcar.png', scale=10)
    
        #define the vehichle object
        car = Bicycle(animation=anim, control=RandomPath, dim=dim,
                      x0=(init_x, init_y, 0), verbose=False)
        #initialize the vehichle (default home at [0,0])
        car.init(plot=True)
    
        #update the vehichle animation to reflect the updated initial position
        car._animation.update(car.x)
    
        #the map matrix is in a MATLAB file that needs to be imported using the loadmat function
        vars = loadmat(
            "/home/yara/.local/lib/python3.6/site-packages/rtbdata/data/map1.mat")
        map = vars['map']
    
        #DXform(map, options): distance transform navigation object
        #map: occupancy grid, a representation of a planar world as a matrix whose elements are 0 (free space) or 1 (occupied).
        dx = DXform(map)
        
        #The method DX.plan(goal) updates the internal distance map where the value of each element is the minimum distance from the corresponding point to the specified goal.
        dx.plan(goal)
    
        #dx.query() method returns an array of all the coordinates that construct the path to the goal
        p = dx.query([init_x, init_y])
    
        dx.plot(path=p)
    
        axes = plt.gca()
        axes.set_xlim([0, dim])
        axes.set_ylim([0, dim])
    
        for n in p:
            go_target(n[0], n[1])
    
        plt.pause(100)
    ```