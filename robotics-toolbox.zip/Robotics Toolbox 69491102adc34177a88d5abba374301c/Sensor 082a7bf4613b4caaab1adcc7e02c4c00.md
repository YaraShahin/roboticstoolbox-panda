# Sensor

# Range Bearing Sensor

- Range and bearing sensor class implements a range and bearing angle sensor that provides robot-centric measurements of point features in the world.
    
    ```python
    #move and stop if there's an obstacle
    
    from roboticstoolbox import Bicycle, VehicleIcon, RandomPath, LandmarkMap, RangeBearingSensor
    import matplotlib.pyplot as plt
    
    if __name__ == "__main__":
        try:
            dim = int(input("Enter grid size: "))
            den = int(input("Enter obstacle density in int percentage: "))
    
            x0 = float(input("Enter initial x of the car: "))
            y0 = float(input("Enter initial y of the car: "))
        
            anim = VehicleIcon('/home/yara/CovCE/Lab09/redcar.png', scale = dim*0.2)
            car = Bicycle(animation=anim, control = RandomPath, dim = dim, x0 = (x0, y0, 0))
            car.init(plot = True)
            car._animation.update(car.x)
            
            #LandmarkMap(#obstacles, from -# to +#): Make a random map with specified number of obstacles in the specified grid area
            map = LandmarkMap(den*dim//100, dim)
            map.plot()
            
            #define a RangebearingSensor(robot, map, animate) object 
            sensor = RangeBearingSensor(robot = car, map = map, animate = True)
            
            dist = [x[0] for x in sensor.h(car.x)]
            ang = [x[1] for x in sensor.h(car.x)] 
            
            print("Sensor readings:")
            print(sensor.h(car.x))
            
            print("Distance readings:")
            print(dist)
            
            print("Angle readings:")
            print(ang)
            
            while min(dist)>5:
                dist = [x[0] for x in sensor.h(car.x)]
                print(min(dist))
                car.step(10, 0.01)
                car._animation.update(car.x)
                plt.pause(0.005)
            
            plt.pause(100)
        except:
            print("Some error occurred")
    ```