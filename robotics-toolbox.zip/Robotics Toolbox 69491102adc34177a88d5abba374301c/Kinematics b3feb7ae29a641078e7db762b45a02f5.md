# Kinematics

[Lecture 9 - Decision Making.pdf](Kinematics%20b3feb7ae29a641078e7db762b45a02f5/Lecture_9_-_Decision_Making.pdf)

- Kinematics is a branch of mechanics that studies the motion of a body (or a
system of bodies), without considering its mass of forces acting on it.
- For a wheeled mobile robot, can be simplified to 2D problem since the robot navigates on the ground plane.
- Types:
    - Forward Kinematics: Given motor rotations, find the resulting robot pose (𝑥, 𝑦, 𝜃).
    - Inverse Kinematics: Given a desired robot pose, find the required motor rotations

# Motion Models

## Ackerman Steering (car-like)

- Turning achieved by mechanically steering where wheels have slightly different steering angles due to difference in radii of rotation.
- Limitation: No rotation possible without moving forward (2 actuators driving a task space dimension of 3)

![Untitled](Kinematics%20b3feb7ae29a641078e7db762b45a02f5/Untitled.png)

- Bicycle Model
    
    ```python
    from roboticstoolbox import Bicycle, RandomPath, VehicleIcon
    import matplotlib.pyplot as plt
    
    dim = 20
    
    #enables the animation of the robot (path, image scale)
    robot_icon = VehicleIcon('/home/yara/CovCE/Lab07/robot.png', scale = 3)
    
    #robot object of the kinematics model bicycle (car-like)
    #animation is the icon to be visualized, default = none
    #x0 is initial pose in (x, y, theta), default = [0. 0. 0.]
    #dim is the grid diameter, default = 10 (10*10 grid)
    #RandomPath control: “driver” object capable of driving a Vehicle object through random waypoints.
    car = Bicycle(animation = robot_icon, control = RandomPath, dim = dim, x0 = (5, 2, 0))
    car.init(plot = True)
    
    #must update the animation with the current (x, y, theta) since the default coordinates are changes in the object instance
    car._animation.update(car.x)
    
    #while the current position in x and y is smaller than the grid, go
    while (abs(car.x[0])<dim and abs(car.x[1])<dim):
        #step takes the speed and the steering angle in radian
        car.step(1, 0)
        car._animation.update(car.x)
        plt.pause(0.005)
    
    #get the plt for 100 seconds
    plt.pause(100)
    ```
    
    ```python
    from roboticstoolbox import Bicycle, VehicleIcon, RandomPath
    import matplotlib.pyplot as plt
    from math import atan2, sqrt
    
    def go_target(X, Y):
        diff_x = 1
        diff_y = 1
        while abs(diff_x)>0.1 and abs(diff_y)>0.1:
            diff_x = X - car.x[0]
            diff_y = Y - car.x[1]
    
            dist =  sqrt(pow(diff_x,2)+pow(diff_y,2))
            ang = atan2(diff_y, diff_x)
    
            car.step(dist*0.5, ang-car.x[2])
            car._animation.update(car.x)
            plt.pause(0.005)
        return
    
    if __name__ == "__main__":
        try:
            dim = int(input("Enter grid size: "))
    
            target_x = float(input("Enter the x of the target: "))
            target_y = float(input("Enter the y of the target: "))
    
            x0 = float(input("Enter initial x of the car: "))
            y0 = float(input("Enter initial y of the car: "))
    
            if target_x>dim or target_y>dim:
                raise ValueError("Error: target cannot be out of grid!")
        
            anim = VehicleIcon('/home/yara/CovCE/Lab07/robot.png', scale = 3)
            car = Bicycle(animation=anim, control = RandomPath, dim = dim, x0 = (x0, y0, 0))
            car.init(plot = True)
            car._animation.update(car.x)
    
            plt.plot(target_x, target_y, marker='D', markersize=6, color='r')
    
            go_target(target_x, target_y)
            plt.pause(100)
        except:
            print("Some error occurred")
    ```
    

## Differential Drive

- Turning achieved by setting different speeds or directions of the wheels at each side of the robot (ex: right wheels going forward while left going reverse)
- Turning achieved by independently controlling the
velocity of opposing wheels 𝑣𝐿and 𝑣𝑅
- Limitation : Robot can’t move sideways, but can rotate around its center without moving forward. (2 actuators driving a task space dimension of 3)
- Unicycle Model

![Untitled](Kinematics%20b3feb7ae29a641078e7db762b45a02f5/Untitled%201.png)

## Omnidirectional Drive

- Can move sideways

![Untitled](Kinematics%20b3feb7ae29a641078e7db762b45a02f5/Untitled%202.png)