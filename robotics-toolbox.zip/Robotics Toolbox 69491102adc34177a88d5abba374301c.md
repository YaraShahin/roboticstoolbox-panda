# Robotics Toolbox

- This toolbox brings robotics-specific functionality to Python, and leverages Python's advantages of portability, ubiquity and support, and the capability of the open-source ecosystem for linear algebra (numpy, scipy), graphics (matplotlib, three.js, WebGL), interactive development (jupyter, jupyterlab, [mybinder.org](http://mybinder.org/)), and documentation (sphinx).
- Features:
    - kinematics and dynamics of serial-link manipulators through creating in DH form, importing a URDF file, or using from the built-in robots
    - mobile robots with functions for robot motion models, path planning algorithms, kinodynamic planning, localization, map building, and SLAMing

# Mobile robots

[Kinematics](Robotics%20Toolbox%2069491102adc34177a88d5abba374301c/Kinematics%20b3feb7ae29a641078e7db762b45a02f5.md)

[Path Planning](Robotics%20Toolbox%2069491102adc34177a88d5abba374301c/Path%20Planning%20b10d43bc768e42e78a8d669fbf8f8bcb.md)

[Sensor](Robotics%20Toolbox%2069491102adc34177a88d5abba374301c/Sensor%20082a7bf4613b4caaab1adcc7e02c4c00.md)

## Projects

[Obstacle Avoidance](https://github.com/YaraShahin/ObstacleAvoidingCar)

# Resources

[robot.pdf](http://www.petercorke.com/RTB/robot.pdf)

[GitHub - petercorke/robotics-toolbox-python: Robotics Toolbox for Python](https://github.com/petercorke/robotics-toolbox-python)

[Robotics Toolbox for Python - Robotics Toolbox for Python documentation](https://petercorke.github.io/robotics-toolbox-python/index.html)

[Robotics Toolbox Lab 1.pdf](Robotics%20Toolbox%2069491102adc34177a88d5abba374301c/Robotics_Toolbox_Lab_1.pdf)

[Robotics Toolbox Lab 2.pdf](Robotics%20Toolbox%2069491102adc34177a88d5abba374301c/Robotics_Toolbox_Lab_2.pdf)

[Robotics Toolbox Lab 3.pdf](Robotics%20Toolbox%2069491102adc34177a88d5abba374301c/Robotics_Toolbox_Lab_3.pdf)